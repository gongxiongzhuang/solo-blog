title: Spring boot 2 添加全局异常拦截
date: '2019-02-26 11:18:20'
updated: '2019-02-26 11:18:20'
tags: [springboot2]
permalink: /articles/2019/02/26/1551150709612.html
---
之前写代码经常在controller控制层的每个方法里面写try catch，现在使用spring boot实现一个全局的异常拦截的功能，不用再controller的每个方法加try catch了。
```
/**
 * 全局的异常拦截
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private Logger logger =  LoggerFactory.getLogger(this.getClass());

    private static final String DEFAULT_ERROR_VIEW = "error";

    @ExceptionHandler(value = Exception.class)
    public ModelAndView defaultErrorHandler(Exception e, HttpServletRequest request) {
        logger.info("请求地址：" + request.getRequestURL());
        ModelAndView mav = new ModelAndView();
        logger.error("异常信息：",e);
        mav.setViewName(DEFAULT_ERROR_VIEW);
        return mav;
    }
}
```
简化后的控制层如下：
![image.png](https://img.hacpai.com/file/2019/02/image-7f1c060f.png)
请求时出现异常信息输出如下：
![image.png](https://img.hacpai.com/file/2019/02/image-5371175b.png)
我们可以发现在控制层没有try catch，但是控制台输出了捕获到的异常信息。
