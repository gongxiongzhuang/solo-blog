title: Spring boot 2 mybatis配置
date: '2019-02-15 17:16:57'
updated: '2019-02-15 19:16:33'
tags: [springboot2]
permalink: /mybatis
---
公司最近需要启动新的项目，需要一套启动框架，因为公司没有其他人了只能我来搭建一套框架，spring boot 是目前比较流行而且简单上手的微服务框架，而且方便拓展(方便后期结合spring cloud做分布式，虽然本人现在还没做过。。)，本人第一次学习框架，可能会有很多不足，请大神们多多指教。
一共有5个步骤：
1.官方配置并下载spring boot 项目
2.添加连接数据的maven依赖
3.配置spring boot 约定的数据库的链接的properties文件(约定大于配置)
4.可以直接开始编写controller,service,dao,以及mapper和dao的映射关系了
5.配置启动类，配置扫描接口类，启动项目

### 第一步：配置一个spring boot 2.x 的项目
直接在官网 https://start.spring.io 配置好之后下载项目，如下图
![imagepng](http://laog-blog.oss-cn-shenzhen.aliyuncs.com/file/2019/02/3230455cf403476ca5014ec281a044e3_image.png) 
下载项目之后用IDEA打开项目，就是一个最基本的spring boot 项目了。关于spring boot 的hello word 的截图我就不贴出来了，接下来直接看怎么连接数据库。

### 第二步：添加mybatis和数据库连接maven依赖
spring boot 项目生成后除了自己选择的依赖之外会自动添加一些依赖，我这里就不说明其作用了，留着就行了....下面是连接数据库最主要的连个依赖mybatis和连接mysql数据库驱动的依赖
```
<properties>
	<mybatis-spring-boot>1.3.2</mybatis-spring-boot>
</properties>
<!-- mybatis -->
<dependency>
	<groupId>org.mybatis.spring.boot</groupId>
	<artifactId>mybatis-spring-boot-starter</artifactId>
	<version>${mybatis-spring-boot}</version>
</dependency>
<!-- mybatis -->

<!-- mysql 连接驱动 -->
<dependency>
	<groupId>mysql</groupId>
	<artifactId>mysql-connector-java</artifactId>
	<scope>runtime</scope>
</dependency>
<!-- mysql 连接驱动 -->
```

### 第三步：配置spring boot properties 文件
spring boot 配置文件会根据约定的参数自动装载，不需要手动配置xml文件，下面是配置mybatis和数据连接的配置。
通用配置application.properties
```
#开发环境为默认配置
spring.profiles.active=dev

#mapper.xml映射文件的路径
mybatis.mapper-locations=classpath:mappers/*.xml   
```   

数据库连接配置mysql,redis配置信息抽出来，为了区分开发、测试和生产环境
数据连接配置application-dev.properties
```
# 数据库连接
spring.datasource.url=jdbc:mysql://120.77.241.0:3306/test?useSSL=false&useUnicode=true&characterEncoding=UTF-8
spring.datasource.username=root
spring.datasource.password=
```

### 第四步：开始编写controller,service,dao以及mapper和dao的映射关系了
首先看一下项目目录结构
![imagepng](http://laog-blog.oss-cn-shenzhen.aliyuncs.com/file/2019/02/ca3ed172fe794759b384b03c481a43de_image.png) 

controller 和 service 就不用说了，和springMvc的写法大致类似，主要看看dao和mapper是怎么映射的。
dao层主要编写操作数据库的接口
```
/**
 * 用户 dao 接口
  */
public interface UserDao {

  User findByName(String name);

  User findById(Long id);

  User findByNameAndUuid(String name, String uuid);
}
```
mybatis里面每个操作数据库的接口是通过映射mapper文件来执行sql语句从而操作数据的，所以每个接口的方法都需要与mapper.xml相对应；
```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.springboot.dao.UserDao">
    <resultMap id="BaseResultMap" type="com.springboot.domain.User">
        <result column="id" property="id" />
        <result column="name" property="name" />
        <result column="age" property="age" />
        <result column="uuid" property="uuid" />
    </resultMap>

    <sql id="Base_Column_List">
        id,name,age,uuid
    </sql>

    <select id="findByName" resultMap="BaseResultMap">
        select <include refid="Base_Column_List"/> from user where name = #{name}
    </select>

    <select id="findById" resultMap="BaseResultMap">
        select * from user where id = #{id,jdbcType=BIGINT}
    </select>

    <select id="findByNameAndUuid" resultMap="BaseResultMap">
        select <include refid="Base_Column_List"/> from user where name = #{name} and uuid = #{uuid,jdbcType=VARCHAR}
    </select>

</mapper>
```
### 第五步：配置启动类
最后一步也是最重要的一步，配置项目的启动类，我们编写了dao接口，并且编写了映射dao接口的mapper文件，但是项目启动的时候还需要配置mapper 接口类扫描包的位置，启动类代码如下：
```
/**
 * spring boot 启动类
  */
@SpringBootApplication
@MapperScan("com.springboot.dao")// mapper 接口类扫描包配置
public class Study2019Application extends SpringBootServletInitializer {

    /**
 * 部署war包需要继承SpringApplicationBuilder，重写configure
 * @param builder
  * @return
  */
  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
      return builder.sources(Study2019Application.class);
  }

   public static void main(String[] args) {
      SpringApplication.run(Study2019Application.class, args);
  }

}
```

配置完成之后直接右键run执行项目，启动后控制台信息如下：

![imagepng](http://laog-blog.oss-cn-shenzhen.aliyuncs.com/file/2019/02/3ecc39784c2d4e09a856207d3e1a83ba_image.png) 
控制台信息里面可以看到项目访问默认端口是8080，直接访问http://localhost:8080/ 就可以访问了。

> <font color=red>声明：本人第一次写博客，请多多指教</font>   
