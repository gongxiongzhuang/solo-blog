title: spring boot2 mybatis-generator自动生成代码配置
date: '2019-02-21 11:32:57'
updated: '2019-02-21 11:35:00'
tags: [springboot2]
permalink: /articles/2019/02/21/1550715917045.html
---
上一篇 [Spring boot 2 mybatis配置](http://www.laog.net/mybatis) 文章讲了 spring boot 怎么连接数据和mybatis的配置，但是每次当创建一张表都要手动配置mapper映射文件，domain实体类和dao数据层；手动配置不仅增加重复的工作量，也容易出错，接下来根据需求来说一下mybatis-generator自动生成工具。
### 第一步：添加maven mybatis-generator 自动生成插件
1. 添加 maven的 插件工具 `mybatis-generator-maven-plugin`；
2. 添加mysql数据库连接驱动`mysql-connector-java`;
3. 添加mybatis-generato核心jar包`mybatis-generator-core`；
4. 配置generatorConfig的位置,注意：若不配置generatorConfig的位置，会默认位置为`src/main/resources`下。；
```
<build>
	<plugins>
		<plugin>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-maven-plugin</artifactId>
		</plugin>
		<!-- mybatis 自动生成插件 -->
		<plugin>
			<!-- mybatis-generator maven 插件 -->
			<groupId>org.mybatis.generator</groupId>
			<artifactId>mybatis-generator-maven-plugin</artifactId>
			<version>1.3.7</version>
			<dependencies>
				<!-- 连接数据库驱动，插件里面需要单独配置 -->
				<dependency>
					<groupId>mysql</groupId>
					<artifactId>mysql-connector-java</artifactId>
					<version>5.1.46</version>
				</dependency>
				<dependency>
					<groupId>org.mybatis.generator</groupId>
					<artifactId>mybatis-generator-core</artifactId>
					<version>1.3.7</version>
				</dependency>
			</dependencies>
			<executions>
				<execution>
					<id>Generate MyBatis Artifacts</id>
					<phase>package</phase>
					<goals>
						<goal>generate</goal>
					</goals>
				</execution>
			</executions>
			<configuration>
				<!-- 配置generatorConfig的位置,注意：若不配置generatorConfig的位置，会默认位置为src/main/resources下。 -->
				<configurationFile>src/main/resources/mybatis-generator.xml</configurationFile>
				<!--允许移动生成的文件 -->
				<verbose>true</verbose>
				<!-- 是否覆盖 -->
				<overwrite>true</overwrite>
			</configuration>
		</plugin>
	</plugins>
</build>
```
添加插件导入maven成功之后如下图：
![image.png](https://img.hacpai.com/file/2019/02/image-82ced959.png)

### 第二步：新增mybatis-generator.xml配置文件
下面是最常用的`mybatis-generator.xml`配置及配置的相关注释说明；
```
<?xml version="1.0" encoding="UTF-8" ?>

<!DOCTYPE generatorConfiguration
        PUBLIC "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN"
        "http://mybatis.org/dtd/mybatis-generator-config_1_0.dtd">

<generatorConfiguration>
    <!-- defaultModelType="flat" 设置复合主键时不单独为主键创建实体 -->
    <context id="mysqlTables" targetRuntime="MyBatis3" defaultModelType="flat">
        <!-- 生成的pojo，将implements Serializable -->
        <plugin type="org.mybatis.generator.plugins.SerializablePlugin"/>

        <!--注释-->
        <commentGenerator>
            <!-- 将数据库中表的字段描述信息添加到注释 -->
            <property name="addRemarkComments" value="true"/>
            <!-- 注释里不添加日期 -->
            <property name="suppressDate" value="true" />
            <!--<property name="suppressAllComments" value="true" /> 会生成重复的xml bean-->
        </commentGenerator>

        <!-- 数据库链接URL，用户名、密码 -->
        <jdbcConnection driverClass="com.mysql.jdbc.Driver"
                        connectionURL="jdbc:mysql://120.77.241.0:3306/test?useUnicode=true&amp;characterEncoding=utf-8&amp;useSSL=false"
                        userId="root" password="123456">
            <property name="nullCatalogMeansCurrent" value="true"/>
        </jdbcConnection>

        <!-- 指定JDBC类型和Java类型如何转换 -->
        <javaTypeResolver>
            <!-- 该属性可以控制是否强制DECIMAL和NUMERIC类型的字段转换为Java类型的java.math.BigDecimal,默认值为false，一般不需要配置。 -->
            <property name="forceBigDecimals" value="false" />
        </javaTypeResolver>

        <!-- 生成model模型，对应的包，存放位置可以指定具体的路径,如/ProjectName/src，也可以使用MAVEN来自动生成 -->
        <javaModelGenerator
                targetPackage="com.springboot.domain" targetProject="src/main/java">
            <!-- 如果true，MBG会根据catalog和schema来生成子包。如果false就会直接用targetPackage属性。默认为false -->
            <property name="enableSubPackages" value="true" />
            <!-- 是否对数据库查询结果进行trim操作，如果设置为true就会生成类似这样public void setUsername(String username) {this.username = username == null ? null : username.trim();}的setter方法。默认值为false -->
            <property name="trimStrings" value="true" />
        </javaModelGenerator>

        <!--对应的xml mapper文件 -->
        <sqlMapGenerator targetProject="src/main/resources" targetPackage="mappers" >
            <property name="enableSubPackages" value="true" />
        </sqlMapGenerator>

        <!-- 对应的dao接口 -->
        <javaClientGenerator targetProject="src/main/java" targetPackage="com.springboot.dao" type="XMLMAPPER">
            <property name="enableSubPackages" value="true" />
        </javaClientGenerator>


        <!-- 要生成的表 tableName是数据库中的表名或视图名 domainObjectName是实体类名（不生成Example（帮助类）类） -->
        <!-- <table tableName="sys_department"
            domainObjectName="SysDepartment" enableCountByExample="false"
            enableSelectByExample="false" enableUpdateByExample="false"
            enableDeleteByExample="false">
        </table> -->
        <!-- <table tableName="t_test"
            domainObjectName="Test" enableCountByExample="true"
            enableSelectByExample="true" enableUpdateByExample="true"
            enableDeleteByExample="true">
        </table> -->
        <!-- 生成所有表 -->
        <!--
             enableCountByExample  生成根据条件统计的dao和mapper映射
             enableSelectByExample 生成根据条件查询的dao和mapper映射
             enableUpdateByExample 生成根据条件修改的dao和mapper映射
             enableDeleteByExample 生成根据条件删除的dao和mapper映射
         -->
        <table tableName="%"
               enableCountByExample="false"
               enableSelectByExample="true"
               enableUpdateByExample="false"
               enableDeleteByExample="false">
        </table>

    </context>

</generatorConfiguration>
```
### 第三步：执行maven插件`mybatis-generator:generate`命令
![image.png](https://img.hacpai.com/file/2019/02/image-1e18f9b8.png)









































