title: mac 解决github.com访问慢和下载慢的问题
date: '2019-02-21 00:46:07'
updated: '2019-02-21 10:06:50'
tags: [mac, github]
permalink: /articles/2019/02/21/1550680868734.html
---
### 第一步：打开hosts文件
* mac 打开终端编辑hosts
````
$ sudo vim /etc/hosts
````
* window 打开hosts文件
快捷键 win + R，键入 `C:\Windows\System32\drivers\etc`  找到hosts文件并且打开
### 第二步：添加配置信息
```
#github
13.229.188.59　　github.com
52.74.223.119    github.com
192.30.253.113   github.com
151.101.73.194   github.global.ssl.fastly.net
151.101.24.133   assets-cdn.github.com
```

### 第三步：不重启电脑让配置立即生效
* mac 刷新dns解析
打开终端执行命令`sudo dscacheutil -flushcache;`
* windows 刷新dns解析
快捷键`win+R`；输入`cmd`；执行命令`ipconfig /flushdns`