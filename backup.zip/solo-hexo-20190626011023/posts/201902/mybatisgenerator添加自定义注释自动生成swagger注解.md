title: mybatis-generator 添加自定义注释自动生成swagger注解
date: '2019-02-26 10:45:35'
updated: '2019-02-26 10:45:35'
tags: [springboot2]
permalink: /articles/2019/02/26/1551146043144.html
---
最近使用mybatis-generator发现自动生成的实体类的注释不是我想要的，我希望自动生成的实体类上面自动添加了swagger的的注解，这样就不用每个实体类再去手动添加注解了。
### 第一步：添加需要的jar包
因为要拓展generator，所以需要引入核心包的支持；
```
<!-- generator-core 自动添加swagger实体类注解 -->
<dependency>
	<groupId>org.mybatis.generator</groupId>
	<artifactId>mybatis-generator-core</artifactId>
	<version>1.3.7</version>
</dependency>
<!-- generator-core 自动添加swagger实体类注解 -->
```
### 第二步：在mybatis-generator.xml配置文件中添加插件配置
```
<!-- 自带插件，实体类序列化 -->
<plugin type="org.mybatis.generator.plugins.SerializablePlugin"/>
<!-- 自定义插件，自动为entity生成swagger2文档-->
<plugin type="com.springboot.MybatisGenerator">
    <property name="apiModelAnnotationPackage" value="io.swagger.annotations.ApiModel" />
    <property name="apiModelPropertyAnnotationPackage" value="io.swagger.annotations.ApiModelProperty" />
</plugin>
```
### 第三步：添加自定义实体类MybatisGenerator.java，路径要和配置文件路径一致
```
public class MybatisGenerator extends PluginAdapter {


	public static void main(String[] args) {
		generate();
	}

	public static void generate() {
		String config = Objects.requireNonNull(MybatisGenerator.class.getClassLoader().getResource("generator/mybatis-generator.xml")).getFile();
		String[] arg = { "-configfile", config, "-overwrite" };
		ShellRunner.main(arg);
	}

	public boolean validate(List<String> list) {
		return true;
	}


	/**
	 * 实体类添加swagger注解
	 * @param field
	 * @param topLevelClass
	 * @param introspectedColumn
	 * @param introspectedTable
	 * @param modelClassType
	 * @return
	 */
	public boolean modelFieldGenerated(Field field, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn,
			IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType) {
		String classAnnotation = "@ApiModel(value=\"" + topLevelClass.getType().getShortName() + "\")";
		if (!topLevelClass.getAnnotations().contains(classAnnotation)) {
			topLevelClass.addAnnotation(classAnnotation);
		}
		String apiModelAnnotationPackage = this.properties.getProperty("apiModelAnnotationPackage");
		String apiModelPropertyAnnotationPackage = this.properties.getProperty("apiModelPropertyAnnotationPackage");
		if (null == apiModelAnnotationPackage) {
			apiModelAnnotationPackage = "io.swagger.annotations.ApiModel";
		}
		if (null == apiModelPropertyAnnotationPackage) {
			apiModelPropertyAnnotationPackage = "io.swagger.annotations.ApiModelProperty";
		}
		topLevelClass.addImportedType(apiModelAnnotationPackage);
		topLevelClass.addImportedType(apiModelPropertyAnnotationPackage);
		field.addAnnotation("@ApiModelProperty(value=\"" + introspectedColumn.getRemarks() +
										   "\",name=\""+introspectedColumn.getJavaProperty()+
										   "\",dataType=\""+introspectedColumn.getFullyQualifiedJavaType().getShortName()+
											"\")");
		return super.modelFieldGenerated(field, topLevelClass, introspectedColumn, introspectedTable, modelClassType);
	}

	/**
	 * 生成dao
	 */
	/*@Override
	public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
		FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType("BaseDao<" + introspectedTable.getBaseRecordType() + ","+introspectedTable.getBaseRecordType()+"Example>");
		FullyQualifiedJavaType imp = new FullyQualifiedJavaType("com.springboot.dao.base.BaseDao");
		interfaze.addSuperInterface(fqjt);// 添加 extends BaseDao<User>
		interfaze.addImportedType(imp);// 添加import common.BaseDao;
		interfaze.getMethods().clear();
		return true;
	}*/
}
```
### 第四步：运行MybatisGenerator.java的main()方法
控制台输出successfufully则生成成功
![image.png](https://img.hacpai.com/file/2019/02/image-ac6ee4a2.png)
自动生成的实体类如下，自动把注解添加上去
![image.png](https://img.hacpai.com/file/2019/02/image-6f8c4ec8.png)
> <font color=red>*注意</font>：因为是自定义实体类的注释，我们去掉了配置文件的`<property name="suppressAllComments" value="true" />`，如果重复生成一张表，则生成的mapper文件会重复追加bean，如果生成重复的表时最好先删除mapper文件，否则会重复生成bean
