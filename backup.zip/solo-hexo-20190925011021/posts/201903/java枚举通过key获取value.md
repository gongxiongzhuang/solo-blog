title: java 枚举通过key获取value
date: '2019-03-25 12:03:22'
updated: '2019-03-25 12:03:22'
tags: [java]
permalink: /articles/2019/03/25/1553486602371.html
---
```
public enum OrderStatus {

    /**
     * 订单状态
     */
    OrderStatus10("10","草稿"),
    OrderStatus11("11","客户驳回"),
    OrderStatus12("12","资方驳回"),
    OrderStatus17("17","废弃"),
    OrderStatus20("20","待客户确认"),
    OrderStatus30("30","待客户支付补款"),
    OrderStatus40("40","待资方审核"),
    OrderStatus50("50","待资方出款"),
    OrderStatus60("60","订单完成"),
    OrderStatus70("70","还款中"),
    OrderStatus71("71","完成还款"),
    OrderStatus80("80","退保中"),
    OrderStatus81("81","退保完成"),
    OrderStatus90("90","还款完成后删除"),

    /**
     * 业务员订单列表显示状态
     */
    SalesmanOrderStatus10("10","草稿"),
    SalesmanOrderStatus11("11","客户驳回"),
    SalesmanOrderStatus12("12","资方驳回"),
    SalesmanOrderStatus17("17","-"),
    SalesmanOrderStatus20("20","待客户确认"),
    SalesmanOrderStatus30("30","待客户补款"),
    SalesmanOrderStatus40("40","待资方审核"),
    SalesmanOrderStatus50("50","待资方出款"),
    SalesmanOrderStatus60("60","已完成"),
    SalesmanOrderStatus70("70","已完成"),
    SalesmanOrderStatus71("71","已完成"),
    SalesmanOrderStatus80("80","已完成"),
    SalesmanOrderStatus81("81","已完成"),

    /**
     * 客户订单列表显示状态
     */
    UserOrderStatus10("10","草稿"),
    UserOrderStatus11("11","已驳回"),
    UserOrderStatus12("12","资方驳回"),
    UserOrderStatus17("17","-"),
    UserOrderStatus20("20","待确认"),
    UserOrderStatus30("30","待补款"),
    UserOrderStatus40("40","待资方审核"),
    UserOrderStatus50("50","待资方出款"),
    UserOrderStatus60("60","已完成"),
    UserOrderStatus70("70","已完成"),
    UserOrderStatus71("71","已完成"),
    UserOrderStatus80("80","已完成"),
    UserOrderStatus81("81","已完成"),
    ;

    private String orderStatus;
    private String value;

    OrderStatus(String orderStatus, String value) {
        this.orderStatus = orderStatus;
        this.value = value;
    }

    public static String getValue(String orderStatus) {
        OrderStatus[] orderStatuses = values();
        for (OrderStatus o : orderStatuses) {
            if (o.getOrderStatus().equals(orderStatus)) {
                return o.getValue();
            }
        }
        return null;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public String getValue() {
        return value;
    }
}

```