title: spring boot 使用 Mybatis 存储 日期格式时相差14小时的问题
date: '2019-03-06 19:18:00'
updated: '2019-03-06 20:13:41'
tags: [springboot2]
permalink: /articles/2019/03/06/1551871080730.html
---
### 问题描述
今天在spring boot 项目中遇到在使用mybatis-generator自动生成的Example进行保存用户信息时，发现存储在数据库中的创建时间和实际时间相差14个小时；下面记录一下问题出现的原因和解决的方法。
### 出现问题原因
spring boot mybatis 日期转化的时区和数据库时区不一致导致。

#### 1. 查询数据库时区
```

show variables like '%time_zone%';
# 查询显示结果：
# system_time_zone: CST
# time_zone:SYSTEM
```
`CST`可为4个不同时区的缩写，可参考[CST](https://www.baidu.com/s?wd=CST&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)

* 美国中部时间：Central Standard Time ([USA](https://www.baidu.com/s?wd=USA&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao))[UT](https://www.baidu.com/s?wd=UT&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)-6:00

* 澳大利亚中部时间：Central Standard Time (Australia)[UT](https://www.baidu.com/s?wd=UT&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)+9:30

* 中国[标准时间](https://www.baidu.com/s?wd=%E6%A0%87%E5%87%86%E6%97%B6%E9%97%B4&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)：China Standard Time[UT](https://www.baidu.com/s?wd=UT&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)+8:00

* 古巴[标准时间](https://www.baidu.com/s?wd=%E6%A0%87%E5%87%86%E6%97%B6%E9%97%B4&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)：Cuba Standard Time UT-4:00

#### 2. 猜想spring boot mybatis 转化日期格式使用的时区
猜想：`com.mysql.cj.jdbc.Driver`转化sql的时候使用的时区是美国中部时间 UTC-06:00
猜想：mysql数据库使用的是默认当地时区也就是中国标准时间 UTC+08:00
这样相加就可以得出时间相差14个小时

#### 3. 解决方法
* 修改数据库时区，需要重启数据库
```
set  global  time_zone = '+08:00';
set  time_zone = '+08:00';
```
设置成功后需要重启数据库   

* 链接数据库的链接上添加时区设置，不用设置数据库时区
```
spring.datasource.url=jdbc:mysql://localhost:3306/test?useTimezone=true&serverTimezone=GMT%2B8
```
意思是链接数据库的时候就设置时区`UTC+8`